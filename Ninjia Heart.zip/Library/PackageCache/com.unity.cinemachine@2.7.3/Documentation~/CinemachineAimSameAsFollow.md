# Same As Follow Target

This Virtual Camera __Aim__ algorithm matches the orientation of the __Follow__ target. When used with the __Hard Lock to Target__ algorithm in the __Body__ properties, this algorithm makes the Virtual Camera match the path and rotation of a control GameObject.

