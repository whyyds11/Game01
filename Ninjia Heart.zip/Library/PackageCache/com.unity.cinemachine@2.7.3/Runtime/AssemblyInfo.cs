﻿using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("com.unity.cinemachine.editor")]
[assembly: InternalsVisibleTo("com.unity.cinemachine.tests")]
